package org.zerock.domain;

import lombok.Data;

@Data
public class DirectorVO {
	private Integer directorid;
	private String directorname;
	private String directorvalue;
}
