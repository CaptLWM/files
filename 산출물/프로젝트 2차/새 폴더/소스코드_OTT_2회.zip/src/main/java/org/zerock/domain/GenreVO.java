package org.zerock.domain;

import lombok.Data;

@Data
public class GenreVO {
	private Integer genreid;
	private String genrename;
	private String genrevalue;
}
